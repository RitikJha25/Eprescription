from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_protect
from django.template.context_processors import csrf
from  . import models 
from .models import Prescribe, Signup
# Create your views here.



def Data(request):
		webp_list= models.Prescribe.objects.order_by('Pname')
		my_dict= {'web_list':webp_list}
		return render(request,'data.html', context=my_dict)

	
def home(request):
	return render(request, 'project.html', )


def index(request):
	if request.method=='GET':
		if Prescribe.objects.filter(Pid = request.GET.get('Pid')).exists():
			medList = models.Prescribe.objects.get(Pid = request.GET.get('Pid')) 
			responses = {'fetchPid':medList}
			return render(request, 'search.html', context = responses)
			
		else:
			responses = {'id_message':"no Id registerd"}
			return render(request,'project.html', context = responses)



@csrf_protect
def form_data(request):
	if request.method == 'POST':
		if Prescribe.objects.filter(Pname = request.POST.get('Pname')).exists():
			user_exist= {'message': "Patient already exists "}
			return render(request,'project.html', context = user_exist)
		if Prescribe.objects.filter(Pname = request.POST.get('Pid')).exists():
			user_exist= {'message': "Patient already exists "}
			return render(request,'project.html', context = user_exist)

		if len(request.POST.get('Pid')) != 6:
			invalid_Pid= {'message' : "invalid Pid"}
			return render(request, 'project.html',context = invalid_Pid)
		if len(request.POST.get('Meds')) >= 100:
			invalid_name= {'message' : "medicines cannot exceed 100 characters"}
			return render(request, 'project.html',context = invalid_name)
		if request.POST.get('Pname') and request.POST.get('Meds') and request.POST.get('Pid'):
			post=Prescribe()
			post.Pname= request.POST.get('Pname')
			post.Meds= request.POST.get('Meds')
			post.Pid= request.POST.get('Pid')
			post.save()
			success = {'message': "Prescription uploaded successflly"}
			return render(request, 'Project.html', context= success)
	else:
		return render(request, 'project.html',)




























