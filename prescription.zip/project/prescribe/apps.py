from django.apps import AppConfig


class PrescribeConfig(AppConfig):
    name = 'prescribe'
