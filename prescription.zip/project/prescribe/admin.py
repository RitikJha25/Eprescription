from django.contrib import admin
from .models import Prescribe

# Register your models here.
admin.site.register(Prescribe)