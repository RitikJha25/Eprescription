from django.db import models

# Create your models here.
class Prescribe(models.Model):
	Pname = models.CharField(max_length = 20, )
	Pid = models.IntegerField()
	Meds = models.CharField(max_length = 100,)


	def __str__(self):
		return self.Pname
		return self.Pid
		return self.Meds